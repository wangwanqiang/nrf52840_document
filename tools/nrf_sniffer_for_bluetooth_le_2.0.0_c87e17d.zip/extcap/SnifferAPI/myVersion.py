version = 1114
versionString = "2.0.0"
versionNameAppendix = "_%s" % str(version)
