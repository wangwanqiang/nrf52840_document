version = 1115
versionString = "3.0.0"
versionNameAppendix = "_%s" % str(version)
